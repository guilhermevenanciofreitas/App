import Error403 from './Error403';

export default Error403;
