import Error500 from './Error500';

export default Error500;
