import Error503 from './Error503';

export default Error503;
