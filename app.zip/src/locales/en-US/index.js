export default {
  id: 'en-US',
  error404: 'Page not found',
  error500: 'Server error'
};
